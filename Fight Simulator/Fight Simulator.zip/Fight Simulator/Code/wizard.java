
public class wizard extends character{
	
	//lowest health highest strength
	public wizard() {
		health = 60;
		strength = 3;
		name = "harry potter";
		Class = "Wizard";
	}
	
	
}
