
public class archer extends character{
	
	//mid health and mid strength
	public archer() {
		health = 80;
		strength = 2;
		name = "Legolas";
		Class = "Archer";
	}
}
