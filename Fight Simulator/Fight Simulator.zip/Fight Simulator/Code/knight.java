
public class knight extends character{
	
	//highest health lowest strength
	public knight() {
		health = 100;
		strength = 1;
		name = "Edward the Black Prince";
		Class = "Knight";
	}
}
